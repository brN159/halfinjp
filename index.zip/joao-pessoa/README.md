# João Pessoa — Road to 3ª Meia

Apresentação interativa da viagem (13–16 nov 2026). HTML, CSS e JavaScript puros, sem build.

## Como rodar

Abra `index.html` no navegador. Se preferir um servidor local:

```bash
cd joao-pessoa
python3 -m http.server 8000   # depois acesse http://localhost:8000
```

Fontes (Google Fonts) e mapa (Leaflet + OpenStreetMap) precisam de internet. Offline, o site usa fontes
do sistema e um mapa esquemático.

## Estrutura

```
index.html          estrutura mínima (topbar, lightbox)
css/style.css       design, cenas, responsivo
js/data.js          TODO o conteúdo: dias, cenas, locais, galeria, checklist, orçamento
js/app.js           montagem dos slides, navegação, contador, mapa, lightbox, checklist, orçamento
assets/images/      day01/ day02/ day03/ day04/ general/
```

## Fotos

Nenhuma foto vem incluída. Sem arquivo, cada slide mostra um degradê no lugar e nada quebra.
Coloque as imagens nas pastas com estes nomes (ou troque os caminhos em `js/data.js`; URLs `https://...` também valem):

| Pasta | Arquivos |
|---|---|
| `general/` | `hero.jpg` (orla de Tambaú/Cabo Branco), `moment-01.jpg` … `moment-09.jpg` |
| `day01/` | `opener`, `manha`, `expo`, `tarde`, `checkin`, `massa`, `orla-noite` (.jpg) |
| `day02/` | `opener`, `manha`, `centro`, `noite`, e uma por ponto: `ccsf`, `igreja-sf`, `hotel-globo`, `antenor-navarro`, `centro-historico` |
| `day03/` | `opener`, `prova`, `praia`, `jacare`, `skybar`, `fim` |
| `day04/` | `opener` |

Use fotos que você tenha direito de usar (próprias ou com licença livre, como as do Wikimedia Commons).

## O que editar

- **Roteiro:** `trip.days[].scenes` em `js/data.js`. Cada cena tem um `type` (opener, steps, feature, statement, places, race, racekm, sunset, skybar, loading).
- **Dia 04:** preencha `options` na cena `d4-loading`; o botão "Continuar planejando" já abre o painel com um bloco de notas.
- **Mapa:** `trip.locations`. Expo e Sky bar estão com `lat/lng: null`; preencha para aparecerem no mapa. As demais coordenadas são aproximadas.
- **Pontos do Centro Histórico:** `trip.places` (sem horários ou preços de propósito).
- **Checklist / orçamento / galeria:** `trip.checklist`, `trip.budget`, `trip.gallery`.
- **Data da prova:** `trip.meta.raceStart` e `raceEnd` (o contador vira "RACE DAY" e depois "PROVA CONCLUÍDA").

## Salvo no navegador (localStorage)

Checklist, valores do orçamento e número de pessoas, campos do Sky bar, horário do pôr do sol e notas do Dia 04.
Os dados ficam no navegador/aparelho em que você preencheu.

## Navegação

Scroll, setas do teclado (↑ ↓ ← →), botões ↑ ↓, links dos dias no topo, swipe horizontal no celular.
Na tela do Centro Histórico, ← → passam pelos cards antes de avançar.
