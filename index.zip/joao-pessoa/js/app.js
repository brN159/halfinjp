/* ==========================================================================
   JOÃO PESSOA · ROAD TO 3ª MEIA — app
   Lê o objeto `trip` (js/data.js) e monta a apresentação.
   Seções: helpers · render · navegação · contador · corrida · mapa ·
           galeria/lightbox · checklist · orçamento · campos salvos
   ========================================================================== */
(function () {
  'use strict';

  /* ---------------------------------------------------------------- helpers */
  const $ = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => Array.from(c.querySelectorAll(s));
  const pad = n => String(n).padStart(2, '0');
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const imgSrc = p => !p ? '' : (window.__IMG && window.__IMG[p]) || (/^(https?:|data:|\/)/.test(p) ? p : trip.meta.imageBase + p);
  const mapsLink = q => 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(q + ' João Pessoa PB');
  const store = {
    get(k, d) { try { const v = localStorage.getItem('jp26.' + k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem('jp26.' + k, JSON.stringify(v)); } catch (e) { /* storage indisponível */ } }
  };
  const bg = (tone, image, alt, pos) =>
    `<div class="bg tone-${tone || 'sea'}">${image ? `<img src="${esc(imgSrc(image))}" alt="${esc(alt || '')}"${pos ? ` style="object-position:${esc(pos)}"` : ''} loading="lazy" onerror="this.remove()">` : ''}</div>`;
  const timeField = key => `<div class="timebox sm"><label for="t-${key}">Horário</label><input type="time" id="t-${key}" data-store="times" data-field="${key}"></div>`;
  const mapLink = q => `<a class="maplink" href="${mapsLink(q)}" target="_blank" rel="noopener">Ver no mapa</a>`;
  const goBtn = (id, label, cls) => `<button type="button" class="btn ${cls || ''}" data-goto="${id}">${label}</button>`;

  /* ----------------------------------------------------------------- render */
  const totalDays = trip.days.length;

  function scene(o, inner, extra) {
    return `<section class="scene type-${o.type}${o.light ? ' light' : ''}${extra ? ' ' + extra : ''}" id="${o.id}" data-type="${o.type}"${o.day ? ` data-day="${o.day}"` : ''}${o.light ? ' data-light="1"' : ''}>
      ${o.bg === false ? '' : bg(o.tone, o.image, o.alt, o.imagePos)}<div class="inner">${inner}</div></section>`;
  }

  function countdownHTML() {
    return `<div class="cd-wrap" data-countdown>
      <div class="countdown" aria-label="Contagem regressiva para a meia maratona">
        <div><b data-u="d">00</b><span>dias</span></div>
        <div><b data-u="h">00</b><span>horas</span></div>
        <div><b data-u="m">00</b><span>minutos</span></div>
        <div><b data-u="s">00</b><span>segundos</span></div>
      </div>
      <p class="cd-status" data-status></p></div>`;
  }

  function timelineHTML(steps) {
    return `<div class="timeline">${steps.map(st => `
      <article class="step rv"><span class="dot"></span>
        ${st.time ? `<time>${esc(st.time)}</time>` : ''}
        <h3>${esc(st.title)}${st.tag ? `<span class="chip">${esc(st.tag)}</span>` : ''}</h3>${st.text ? `<p>${esc(st.text)}</p>` : ''}
        ${st.mapQuery || st.timeField ? `<div class="step-actions">${st.timeField ? timeField(st.timeField) : ''}${st.mapQuery ? mapLink(st.mapQuery) : ''}</div>` : ''}
        ${st.ideas ? (st.ideas.length
          ? `<div class="ideas">${st.ideas.map(i => `<span>${esc(i)}</span>`).join('')}</div>`
          : `<div class="ideas empty"><span>Espaço para sugestões — edite js/data.js</span></div>`) : ''}
      </article>`).join('')}</div>`;
  }

  const SCENES = {
    opener(s, d) {
      return scene({ ...s, day: d.day }, `<div class="opener">
        <span class="numeral rv">${pad(d.day)}</span>
        <div class="op-text"><h2 class="display rv">${esc(d.title)}</h2>
          <p class="lead rv">${esc(s.subtitle)}</p><p class="date rv">${esc(d.date)}</p></div></div>`);
    },
    steps(s, d) {
      return scene({ ...s, day: d.day }, `<div class="split">
        <header class="head"><p class="kicker rv">${esc(s.kicker)}</p><h2 class="h2 rv">${esc(s.title)}</h2>${s.lead ? `<p class="lead rv">${esc(s.lead)}</p>` : ''}</header>
        ${timelineHTML(s.steps)}</div>`);
    },
    feature(s, d) {
      const fig = s.figure ? `<figure class="fig rv"><img src="${esc(imgSrc(s.figure.src))}" alt="${esc(s.figure.caption || '')}" loading="lazy" onerror="this.closest('figure').remove()"><figcaption>${esc(s.figure.caption || '')}</figcaption></figure>` : '';
      const extras = (s.timeField || s.mapQuery) ? `<div class="btn-row rv">${s.mapQuery ? `<a class="btn solid" href="${mapsLink(s.mapQuery)}" target="_blank" rel="noopener">Ver no mapa</a>` : ''}${s.timeField ? timeField(s.timeField) : ''}</div>` : '';
      return scene({ ...s, day: d.day }, `<div class="feature${s.figure ? ' with-fig' : ''}"><div class="ftext">
        ${s.big ? `<div class="bigtime rv">${esc(s.big)}</div>` : ''}
        <p class="kicker rv">${esc(s.kicker || '')}</p>
        <h2 class="display rv">${esc(s.title)}</h2>
        ${s.tags ? `<div class="tagline rv">${s.tags.map(t => `<span>${esc(t)}</span>`).join('')}</div>` : ''}
        <p class="lead rv">${esc(s.text || '')}</p>
        ${s.address ? `<p class="address rv">${esc(s.address)}</p>` : ''}
        ${extras}</div>${fig}</div>`, s.big ? 'has-big' : '');
    },
    statement(s, d) {
      return scene({ ...s, day: d.day }, `<div class="statement">
        ${s.lines.map(l => `<div class="line rv">${esc(l)}</div>`).join('')}
        ${s.note ? `<p class="note rv">${esc(s.note)}</p>` : ''}</div>`, s.note ? 'calm' : '');
    },
    places(s, d) {
      const list = (s.placeIds || []).map(id => trip.places.find(p => p.id === id)).filter(Boolean);
      return scene({ ...s, day: d.day }, `
        <div class="places-head"><header><p class="kicker rv">${esc(s.kicker)}</p><h2 class="h2 rv">${esc(s.title)}</h2></header>
          <div class="strip-nav rv"><button class="icon-btn" data-strip="-1" aria-label="Anterior">←</button><span data-strip-count>1 / ${list.length}</span><button class="icon-btn" data-strip="1" aria-label="Próximo">→</button></div></div>
        <div class="strip" tabindex="0" aria-label="Pontos do Centro Histórico">${list.map((p, i) => `
          <article class="place rv">
            <div class="pbg tone-hist">${p.image ? `<img src="${esc(imgSrc(p.image))}" alt="${esc(p.name)}" loading="lazy" onerror="this.remove()">` : ''}</div>
            <div class="ptext"><h3>${esc(p.name)}</h3><p>${esc(p.desc)}</p>
              <div class="btn-row"><a class="btn" href="${mapsLink(p.query)}" target="_blank" rel="noopener">Ver no mapa</a>
              <button class="btn" type="button" data-lb-place="${i}">Ampliar</button></div></div>
          </article>`).join('')}</div>`, '');
    },
    race(s, d) {
      return scene({ ...s, day: d.day }, `
        <div class="race-top"><span class="numeral rv">${pad(d.day)}</span>
          <div><div class="race-word rv">RACE<br>DAY</div><div class="race-km rv">21,1 km</div></div></div>
        <div class="race-bottom rv">${countdownHTML()}<p class="lead">${esc(d.date)}${s.start ? ` — largada às ${esc(s.start.time)}, ${esc(s.start.place.charAt(0).toLowerCase() + s.start.place.slice(1))}.` : ' — a meia maratona.'}</p></div>`);
    },
    racekm(s, d) {
      const marks = s.marks || [0, 5, 10, 15, 21.1];
      return scene({ ...s, day: d.day }, `
        <header class="rhead"><p class="kicker rv">${esc(s.kicker)}</p><h2 class="h2 rv">${esc(s.title)}</h2></header>
        ${s.start ? `<div class="startinfo rv"><span class="k">Local da largada · ${esc(s.start.time)}</span><strong>${esc(s.start.place)}</strong><span>${esc(s.start.address)}</span><a class="btn solid" href="${mapsLink(s.start.mapQuery)}" target="_blank" rel="noopener">Ver no mapa</a></div>` : ''}
        <div class="rsteps">${s.steps.map((st, i) => `<div class="rstep rv"><span class="n">${pad(i + 1)}</span>${st.time ? `<time>${esc(st.time)}</time>` : ''}<h3>${esc(st.title)}</h3></div>`).join('')}</div>
        <div class="kmreadout rv"><b data-km>0,0</b><span>km</span></div>
        <div class="track rv" data-track><div class="track-fill"></div><div class="track-marker"></div>
          ${marks.map(m => `<span class="tick" data-km-mark="${m}" style="left:${(m / 21.1 * 100).toFixed(2)}%">${String(m).replace('.', ',')} km</span>`).join('')}</div>
        <button class="replay rv" type="button" data-replay>Rever a prova</button>`);
    },
    sunset(s, d) {
      return scene({ ...s, day: d.day }, `<div class="sunset-grid">
        <h2 class="display sunset-title rv">${esc(s.title)}</h2>
        <div class="sunset-side"><p class="lead rv">${esc(s.text)}</p>
          <div class="timebox rv"><label for="sunsetTime">Horário do pôr do sol</label>
            <input type="time" id="sunsetTime" data-store="sunset" data-field="time"><small>Toque para atualizar</small></div>
          <div class="btn-row rv" style="margin-top:0"><a class="btn solid" href="${mapsLink(s.mapQuery || s.title)}" target="_blank" rel="noopener">VER NO MAPA</a></div></div></div>`);
    },
    skybar(s, d) {
      const keys = ['horario', 'endereco', 'reserva', 'obs'];
      return scene({ ...s, day: d.day }, `<div class="skybar-grid">
        <div><h2 class="display rv">${esc(s.title)}</h2><p class="lead rv">${esc(s.text)}</p>
          <div class="btn-row rv"><a class="btn" id="skybarMap" href="${mapsLink('Sky bar')}" target="_blank" rel="noopener">Ver no mapa</a></div></div>
        <div class="fields rv">${trip.skybar.fields.map((f, i) => i === 3
          ? `<div class="field"><label for="sb${i}">${esc(f)}</label><textarea id="sb${i}" data-store="skybar" data-field="${keys[i]}" placeholder="A definir"></textarea></div>`
          : `<div class="field"><label for="sb${i}">${esc(f)}</label><input id="sb${i}" type="${i === 0 ? 'time' : 'text'}" data-store="skybar" data-field="${keys[i]}" placeholder="A definir"></div>`).join('')}</div></div>`);
    },
    loading(s, d) {
      return scene({ ...s, day: d.day }, `<div class="loading-box">
        <span class="numeral rv">${pad(d.day)}</span>
        <h2 class="display rv">Carregando<span class="dots"></span></h2>
        <div class="loadbar rv"><i></i></div>
        <p class="lead rv">${esc(s.text)}</p>
        <button class="btn solid rv" type="button" id="day4Btn" aria-expanded="false">CONTINUAR PLANEJANDO</button>
        <div class="day4-panel" id="day4Panel" hidden>
          ${(s.options || []).map(o => `<div class="opt"><h4>${esc(o.title)}</h4><p>${esc(o.text || '')}</p></div>`).join('')}
          <div class="field"><label for="d4notes">Ideias para o Dia 04</label><textarea id="d4notes" data-store="day4" data-field="notes" placeholder="Anote aqui o que quer encaixar no último dia."></textarea></div>
        </div></div>`);
    }
  };

  function renderHero() {
    const m = trip.meta;
    return `<section class="scene type-hero" id="hero" data-type="hero">${bg('sea', m.heroImage, 'Orla de Tambaú e Cabo Branco')}
      <div class="inner">
        <div class="hero-top rv"><span>${esc(m.place)}</span><span class="date">${esc(m.range)}</span></div>
        <div class="hero-title">
          <h1 class="display rv">JOÃO<br>PESSOA</h1>
          <p class="road rv">ROAD TO 3ª MEIA</p>
          <div class="hero-mid rv"><span class="hero-date">${esc(m.range)}</span>${countdownHTML()}</div>
        </div>
        <div class="scroll-cue rv"><span>SCROLL TO EXPLORE</span><i></i></div>
      </div></section>`;
  }

  function renderIntro() {
    const it = trip.intro;
    return `<section class="scene type-intro light" id="intro" data-type="intro" data-light="1">${bg('sand')}
      <div class="inner"><div class="intro-lines">${it.lines.map(l => `<div class="display rv">${esc(l)}</div>`).join('')}</div>
      <p class="intro-text rv">${esc(it.text)}</p></div></section>`;
  }

  function renderMap() {
    const L = trip.locations;
    return `<section class="scene type-map" id="map-section" data-type="map">${bg('deep')}
      <div class="inner">
        <div class="map-head"><h2 class="display rv" style="font-size:clamp(3rem,9vw,8rem)">THE MAP</h2><p class="lead rv">Os pontos do roteiro. Edite as coordenadas em js/data.js.</p></div>
        <div class="map-layout rv"><div id="map" role="region" aria-label="Mapa do roteiro"></div>
          <ul class="loclist">${L.map((l, i) => `<li><button type="button" data-loc="${l.id}" class="${l.lat == null ? 'pending' : ''}"><span class="n">${pad(i + 1)}</span><span><strong>${esc(l.name)}</strong><small>${l.lat == null ? 'definir local' : esc(l.note || '')}${l.day ? ' · dia ' + pad(l.day) : ''}</small></span></button></li>`).join('')}</ul></div>
      </div></section>`;
  }

  function renderMoments() {
    return `<section class="scene type-moments light" id="moments" data-type="moments" data-light="1">${bg('paper')}
      <div class="inner"><div class="sec-head"><h2 class="display rv" style="font-size:clamp(3rem,9vw,8rem)">MOMENTS</h2><p class="lead rv">Fotos da viagem. Troque os arquivos em assets/images/general/.</p></div>
      <div class="gallery rv">${trip.gallery.map((g, i) => `<button type="button" class="g g-${g.size || 'sm'} tone-${g.tone || 'sea'}" data-lb-g="${i}" aria-label="Abrir ${esc(g.caption)}">
        <img src="${esc(imgSrc(g.src))}" alt="${esc(g.caption)}" loading="lazy" onerror="this.remove()"><span class="cap">${esc(g.caption)}</span></button>`).join('')}</div></div></section>`;
  }

  function renderChecklist() {
    return `<section class="scene type-check light" id="checklist" data-type="check" data-light="1">${bg('sand')}
      <div class="inner"><div><h2 class="display rv" style="font-size:clamp(3rem,8vw,7rem)">ANTES<br>DE IR</h2><div class="check-count rv" id="checkCount"></div></div>
      <ul class="checks rv" id="checks"></ul></div></section>`;
  }

  function renderBudget() {
    return `<section class="scene type-budget" id="budget" data-type="budget">${bg('deep')}
      <div class="inner"><div><h2 class="display rv" style="font-size:clamp(3rem,8vw,7rem);margin-bottom:28px">TRIP<br>BUDGET</h2><div class="budget-rows rv" id="budgetRows"></div></div>
      <div class="sums rv"><div class="sum total"><div class="lbl">TOTAL DA VIAGEM</div><div class="val" id="sumTotal">R$ 0,00</div></div>
        <div class="two"><div class="sum sm"><div class="lbl">GASTO POR DIA</div><div class="val" id="sumDay">R$ 0,00</div></div>
          <div class="sum sm"><div class="lbl">GASTO POR PESSOA</div><div class="val" id="sumPerson">R$ 0,00</div></div></div>
        <div class="people"><label for="people">Pessoas na viagem</label><input id="people" inputmode="numeric" type="number" min="1" max="20"></div></div></div></section>`;
  }

  function renderTimeline() {
    return `<section class="scene type-timeline light" id="timeline" data-type="timeline" data-light="1">${bg('sand')}
      <div class="inner"><h2 class="display rv" style="font-size:clamp(3rem,8vw,7rem);margin-bottom:28px">A VIAGEM<br>EM QUATRO DIAS</h2>
      <ol class="tl rv">${trip.days.map(d => `<li><button type="button" data-goto-day="${d.day}"><span class="d">${esc(d.short)}</span>
        <span class="t">${esc(d.title.toUpperCase())}<span class="a">${esc(d.activities.join(' · '))}</span></span></button></li>`).join('')}</ol>
      <p class="end-note rv">Clique em um dia para voltar ao slide.</p></div></section>`;
  }

  function buildDeck() {
    const html = [renderHero(), renderIntro()];
    trip.days.forEach(d => d.scenes.forEach(s => html.push(SCENES[s.type](s, d))));
    html.push(renderMap(), renderMoments(), renderChecklist(), renderBudget(), renderTimeline());
    $('#deck').innerHTML = html.join('');

    // nav dos dias
    $('#daynav').innerHTML =
      trip.days.map(d => `<a href="#${d.scenes[0].id}" data-goto-day="${d.day}" data-nav-day="${d.day}"><span class="lbl">Dia&nbsp;</span>${pad(d.day)}</a>`).join('') +
      `<span class="sep"></span>` +
      [['map-section', 'Mapa'], ['moments', 'Fotos'], ['checklist', 'Lista'], ['budget', 'Orçamento'], ['timeline', 'Dias']]
        .map(([id, l]) => `<a class="extra" href="#${id}" data-goto="${id}">${l}</a>`).join('');
  }

  /* ------------------------------------------------------------- navegação */
  let scenes = [], current = -1, ticking = false;

  const goToIndex = i => {
    i = Math.max(0, Math.min(scenes.length - 1, i));
    scenes[i].scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' });
  };
  const goToId = id => { const i = scenes.findIndex(s => s.id === id); if (i > -1) goToIndex(i); };
  const goToDay = n => { const i = scenes.findIndex(s => +s.dataset.day === n); if (i > -1) goToIndex(i); };
  const step = dir => goToIndex((current < 0 ? 0 : current) + dir);

  function setCurrent(i) {
    if (i === current) return;
    current = i;
    const s = scenes[i];
    // dia ativo: antes do primeiro dia = 0; depois do último = total
    let day = +s.dataset.day || 0;
    if (!day) day = i < scenes.findIndex(x => x.dataset.day) ? 0 : totalDays;
    $('#counter').textContent = `${pad(day)} / ${pad(totalDays)}`;
    $$('[data-nav-day]').forEach(a => a.classList.toggle('on', +a.dataset.navDay === (+s.dataset.day || -1)));
    $$('.daynav .extra').forEach(a => a.classList.toggle('on', a.dataset.goto === s.id));
    document.body.classList.toggle('light', !!s.dataset.light);
  }

  function onScroll() {
    ticking = false;
    const vh = window.innerHeight, mid = vh / 2;
    let cur = 0;
    scenes.forEach((s, i) => {
      const r = s.getBoundingClientRect();
      if (r.top <= mid && r.bottom > mid) cur = i;
      if (!reduce && s._bg && r.bottom > -vh && r.top < vh * 2) {
        s._bg.style.setProperty('--py', ((r.top + r.height / 2 - mid) / vh * -5).toFixed(2) + '%');
      }
    });
    setCurrent(cur);
    const max = document.documentElement.scrollHeight - vh;
    const p = max > 0 ? Math.min(1, Math.max(0, window.scrollY / max)) : 0;
    $('#progressFill').style.transform = `scaleX(${p})`;
    $('#miniFill').style.transform = `scaleX(${p})`;
  }
  const requestTick = () => { if (!ticking) { ticking = true; requestAnimationFrame(onScroll); } };

  function initNav() {
    scenes = $$('.scene');
    scenes.forEach(s => {
      s._bg = $('.bg', s);
      $$('.rv', s).forEach((el, i) => el.style.setProperty('--i', i));
    });

    window.addEventListener('scroll', requestTick, { passive: true });
    window.addEventListener('resize', requestTick);
    $('#prev').addEventListener('click', () => step(-1));
    $('#next').addEventListener('click', () => step(1));

    // cliques de navegação (delegação)
    document.addEventListener('click', e => {
      const g = e.target.closest('[data-goto]'); if (g) { e.preventDefault(); goToId(g.dataset.goto); return; }
      const d = e.target.closest('[data-goto-day]'); if (d) { e.preventDefault(); goToDay(+d.dataset.gotoDay); }
    });

    // teclado
    document.addEventListener('keydown', e => {
      if (!$('#lightbox').hidden) return;
      const t = e.target;
      if (t.closest && t.closest('input, textarea, select, [contenteditable]')) return;
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      const keys = { ArrowDown: 1, ArrowRight: 1, ArrowUp: -1, ArrowLeft: -1 };
      if (!(e.key in keys)) return;
      const dir = keys[e.key];
      const s = scenes[current];
      // na cena de pontos turísticos, ← → percorrem os cards antes de mudar de slide
      if (s && s.dataset.type === 'places' && (e.key === 'ArrowRight' || e.key === 'ArrowLeft')) {
        const strip = $('.strip', s);
        const atEnd = strip.scrollLeft + strip.clientWidth >= strip.scrollWidth - 6;
        const atStart = strip.scrollLeft <= 6;
        if ((dir > 0 && !atEnd) || (dir < 0 && !atStart)) { e.preventDefault(); slideStrip(strip, dir); return; }
      }
      e.preventDefault();
      step(dir);
    });

    // swipe horizontal (celular) — o vertical já é o scroll nativo com snap
    let sx = 0, sy = 0, skip = false;
    document.addEventListener('touchstart', e => {
      const t = e.touches[0]; sx = t.clientX; sy = t.clientY;
      skip = !!e.target.closest('.strip, .gallery, input, textarea, #map, .lightbox, .track');
    }, { passive: true });
    document.addEventListener('touchend', e => {
      if (skip || !$('#lightbox').hidden) return;
      const t = e.changedTouches[0], dx = t.clientX - sx, dy = t.clientY - sy;
      if (Math.abs(dx) > 70 && Math.abs(dx) > Math.abs(dy) * 1.6) step(dx < 0 ? 1 : -1);
    }, { passive: true });

    // entrada das cenas
    const thresholds = Array.from({ length: 11 }, (_, i) => i / 10);
    const io = new IntersectionObserver(entries => entries.forEach(en => {
      const s = en.target;
      const need = Math.min(window.innerHeight, en.boundingClientRect.height) * 0.3;
      if (en.isIntersecting && en.intersectionRect.height >= need) {
        if (!s.classList.contains('in')) { s.classList.add('in'); s._enter && s._enter(); }
      } else if (!en.isIntersecting && s.classList.contains('in')) {
        s.classList.remove('in'); s._leave && s._leave();
      }
    }), { threshold: thresholds });
    scenes.forEach(s => io.observe(s));

    onScroll();
  }

  /* ------------------------------------------------------ places (strip) */
  function slideStrip(strip, dir) {
    const card = $('.place', strip);
    const w = card ? card.getBoundingClientRect().width + 16 : strip.clientWidth * .8;
    strip.scrollBy({ left: dir * w, behavior: reduce ? 'auto' : 'smooth' });
  }
  function initPlaces() {
    $$('.type-places').forEach(s => {
      const strip = $('.strip', s), label = $('[data-strip-count]', s), cards = $$('.place', strip);
      $$('[data-strip]', s).forEach(b => b.addEventListener('click', () => slideStrip(strip, +b.dataset.strip)));
      strip.addEventListener('scroll', () => {
        const w = cards[0].getBoundingClientRect().width + 16;
        label.textContent = `${Math.min(cards.length, Math.round(strip.scrollLeft / w) + 1)} / ${cards.length}`;
      }, { passive: true });
    });
  }

  /* --------------------------------------------------------------- contador */
  function initCountdown() {
    const start = new Date(trip.meta.raceStart).getTime(), end = new Date(trip.meta.raceEnd).getTime();
    const boxes = $$('[data-countdown]');
    function tick() {
      const now = Date.now();
      boxes.forEach(b => {
        if (now >= start - 0 && now < end || now >= end) {
          b.classList.add('done');
          $('[data-status]', b).textContent = now < end ? 'RACE DAY' : 'PROVA CONCLUÍDA';
          return;
        }
        b.classList.remove('done');
        let diff = Math.floor((start - now) / 1000);
        const d = Math.floor(diff / 86400); diff -= d * 86400;
        const h = Math.floor(diff / 3600); diff -= h * 3600;
        const m = Math.floor(diff / 60), s = diff - m * 60;
        const set = (u, v) => { const el = $(`[data-u="${u}"]`, b); if (el) el.textContent = pad(v); };
        set('d', d); set('h', h); set('m', m); set('s', s);
      });
    }
    tick(); setInterval(tick, 1000);
  }

  /* ----------------------------------------------- animação dos 21,1 km */
  function initRace() {
    const sc = $('.type-racekm'); if (!sc) return;
    const fill = $('.track-fill', sc), marker = $('.track-marker', sc), out = $('[data-km]', sc);
    const ticks = $$('.tick', sc), TOTAL = 21.1, DUR = reduce ? 1 : 8500;
    let raf = 0;
    const paint = km => {
      const pct = km / TOTAL * 100;
      fill.style.width = pct + '%'; marker.style.left = pct + '%';
      out.textContent = km.toFixed(1).replace('.', ',');
      ticks.forEach(t => t.classList.toggle('lit', km >= parseFloat(t.dataset.kmMark) - 0.05));
    };
    const run = () => {
      cancelAnimationFrame(raf);
      const t0 = performance.now() + 1100;
      (function frame(now) {
        const p = Math.min(1, Math.max(0, (now - t0) / DUR));
        const e = p < .5 ? 2 * p * p : 1 - Math.pow(-2 * p + 2, 2) / 2;
        paint(TOTAL * e);
        if (p < 1) raf = requestAnimationFrame(frame);
      })(performance.now());
    };
    sc._enter = run;
    sc._leave = () => { cancelAnimationFrame(raf); paint(0); };
    $('[data-replay]', sc).addEventListener('click', run);
    paint(0);
  }

  /* ------------------------------------------------------------------- mapa */
  function loadLeaflet(cb) {
    if (window.L) return cb(true);
    const s = document.createElement('script');
    s.src = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js';
    s.onload = () => cb(!!window.L); s.onerror = () => cb(false);
    document.head.appendChild(s);
  }

  function stylizedMap(el) {
    const W = 400, H = 500, minLng = -34.95, maxLng = -34.75, minLat = -7.32, maxLat = -6.94;
    const X = lng => (lng - minLng) / (maxLng - minLng) * W, Y = lat => (maxLat - lat) / (maxLat - minLat) * H;
    const coast = [[-6.94, -34.845], [-6.98, -34.838], [-7.03, -34.831], [-7.08, -34.826], [-7.115, -34.823], [-7.14, -34.812], [-7.15, -34.795], [-7.18, -34.80], [-7.23, -34.805], [-7.28, -34.795], [-7.32, -34.79]];
    const pts = coast.map(c => `${X(c[1]).toFixed(1)},${Y(c[0]).toFixed(1)}`).join(' ');
    const land = `0,0 ${pts} 0,${H}`.replace(/^0,0 /, `0,0 ${X(coast[0][1])},0 `);
    const marks = trip.locations.map((l, i) => l.lat == null ? '' :
      `<g transform="translate(${X(l.lng).toFixed(1)},${Y(l.lat).toFixed(1)})"><circle r="9" fill="#f3a34b" stroke="#fbf8f1" stroke-width="2"/><text y="3.5" text-anchor="middle" style="fill:#06080c;font-weight:600;font-size:9px">${i + 1}</text></g>`).join('');
    el.innerHTML = `<svg class="stylized" viewBox="0 0 ${W} ${H}" preserveAspectRatio="xMidYMid slice" role="img" aria-label="Mapa esquemático do litoral">
      <rect width="${W}" height="${H}" fill="#0c2a4d"/><polygon points="${land}" fill="#d6c4a0" opacity=".9"/>
      <polyline points="${pts}" fill="none" stroke="#fbf8f1" stroke-width="1.2" opacity=".7"/>${marks}
      <text class="cap" x="12" y="${H - 12}">Representação esquemática · a integração com mapa real carrega com internet</text></svg>`;
  }

  function initMap() {
    const el = $('#map'); if (!el) return;
    const msc = $('#map-section'), withCoords = trip.locations.filter(l => l.lat != null);
    let map = null, markers = {};
    loadLeaflet(ok => {
      if (!ok) { stylizedMap(el); return; }
      map = L.map(el, { scrollWheelZoom: false, zoomControl: true });
      L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 18, attribution: '&copy; OpenStreetMap' }).addTo(map);
      withCoords.forEach(l => {
        const n = trip.locations.indexOf(l) + 1;
        markers[l.id] = L.marker([l.lat, l.lng], { icon: L.divIcon({ className: '', html: `<div class="pin">${n}</div>`, iconSize: [28, 28], iconAnchor: [14, 14] }) })
          .addTo(map).bindPopup(`<strong>${esc(l.name)}</strong><br>${esc(l.note || '')}`);
      });
      map.fitBounds(L.latLngBounds(withCoords.map(l => [l.lat, l.lng])), { padding: [40, 40] });
      msc._enter = () => setTimeout(() => map.invalidateSize(), 200);
    });
    $$('[data-loc]').forEach(b => b.addEventListener('click', () => {
      const l = trip.locations.find(x => x.id === b.dataset.loc);
      if (!l) return;
      if (l.lat == null) { window.open(mapsLink(l.query || l.name), '_blank', 'noopener'); return; }
      if (map) { map.flyTo([l.lat, l.lng], 15, { duration: reduce ? 0 : 1.2 }); markers[l.id].openPopup(); }
    }));
  }

  /* --------------------------------------------------------- galeria + lightbox */
  const lb = { list: [], i: 0, scale: 1 };
  function lbShow() {
    const it = lb.list[lb.i], stage = $('#lbStage');
    lb.scale = 1; stage.classList.remove('zoomed'); stage.innerHTML = '';
    const im = new Image();
    im.alt = it.caption || ''; im.draggable = false;
    im.onerror = () => {
      im.remove();
      const ph = document.createElement('div');
      ph.className = `lb-ph tone-${it.tone || 'sea'}`;
      ph.textContent = `Adicione a foto: ${it.src}`;
      stage.appendChild(ph);
    };
    im.src = imgSrc(it.src);
    stage.appendChild(im);
    $('#lbCap').textContent = it.caption || '';
    $('#lbCount').textContent = `${lb.i + 1} / ${lb.list.length}`;
    const multi = lb.list.length > 1;
    $('#lbPrev').style.display = $('#lbNext').style.display = multi ? '' : 'none';
  }
  function lbApply() {
    const im = $('#lbStage img'); if (!im) return;
    im.style.transform = `scale(${lb.scale})`;
    $('#lbStage').classList.toggle('zoomed', lb.scale > 1);
  }
  function lbOpen(list, i) {
    lb.list = list; lb.i = i; lbShow();
    $('#lightbox').hidden = false; document.body.style.overflow = 'hidden';
    $('#lbClose').focus();
  }
  function lbClose() { $('#lightbox').hidden = true; document.body.style.overflow = ''; }
  const lbMove = d => { lb.i = (lb.i + d + lb.list.length) % lb.list.length; lbShow(); };

  function initLightbox() {
    $('#lbClose').addEventListener('click', lbClose);
    $('#lbPrev').addEventListener('click', () => lbMove(-1));
    $('#lbNext').addEventListener('click', () => lbMove(1));
    $('#lbZoom').addEventListener('click', () => { lb.scale = lb.scale > 1 ? 1 : 2.2; lbApply(); });
    const stage = $('#lbStage');
    stage.addEventListener('click', e => {
      if (e.target === stage || e.target.tagName === 'IMG') { lb.scale = lb.scale > 1 ? 1 : 2.2; lbApply(); }
    });
    stage.addEventListener('pointermove', e => {
      const im = $('img', stage); if (!im || lb.scale <= 1) return;
      const r = im.getBoundingClientRect();
      im.style.transformOrigin = `${((e.clientX - r.left) / r.width * 100).toFixed(1)}% ${((e.clientY - r.top) / r.height * 100).toFixed(1)}%`;
    });
    stage.addEventListener('wheel', e => {
      e.preventDefault();
      lb.scale = Math.min(3.5, Math.max(1, lb.scale + (e.deltaY < 0 ? .3 : -.3))); lbApply();
    }, { passive: false });
    document.addEventListener('keydown', e => {
      if ($('#lightbox').hidden) return;
      if (e.key === 'Escape') lbClose();
      else if (e.key === 'ArrowRight') lbMove(1);
      else if (e.key === 'ArrowLeft') lbMove(-1);
      else if (e.key === '+' || e.key === '=') { lb.scale = Math.min(3.5, lb.scale + .4); lbApply(); }
      else if (e.key === '-') { lb.scale = Math.max(1, lb.scale - .4); lbApply(); }
    });
    // abrir: galeria e pontos turísticos
    const gallery = trip.gallery.map(g => ({ src: g.src, caption: g.caption, tone: g.tone }));
    $$('[data-lb-g]').forEach(b => b.addEventListener('click', () => lbOpen(gallery, +b.dataset.lbG)));
    const places = trip.places.map(p => ({ src: p.image, caption: p.name, tone: 'hist' }));
    const placeSc = trip.days.flatMap(d => d.scenes).find(s => s.type === 'places');
    const ids = (placeSc && placeSc.placeIds) || [];
    const list = ids.map(id => places[trip.places.findIndex(p => p.id === id)]).filter(Boolean);
    $$('[data-lb-place]').forEach(b => b.addEventListener('click', () => lbOpen(list, +b.dataset.lbPlace)));
  }

  /* --------------------------------------------------------------- checklist */
  function initChecklist() {
    const ul = $('#checks'); if (!ul) return;
    const flat = trip.checklist.flatMap(g => g.items);
    let done = store.get('check', []);
    const render = () => {
      let i = 0;
      ul.innerHTML = trip.checklist.map(g => `<li class="grp">${esc(g.group)}</li>` + g.items.map(item =>
        `<li><button type="button" class="check" data-ci="${i++}" aria-pressed="${done.includes(item)}"><span class="box">✓</span><span class="txt">${esc(item)}</span></button></li>`).join('')).join('');
      const n = flat.filter(x => done.includes(x)).length;
      $('#checkCount').innerHTML = `${n}<small> de ${flat.length}</small>`;
    };
    ul.addEventListener('click', e => {
      const b = e.target.closest('[data-ci]'); if (!b) return;
      const item = flat[+b.dataset.ci];
      done = done.includes(item) ? done.filter(x => x !== item) : done.concat(item);
      store.set('check', done); render();
      const again = $(`[data-ci="${b.dataset.ci}"]`); if (again) again.focus();
    });
    render();
  }

  /* --------------------------------------------------------------- orçamento */
  function initBudget() {
    const rows = $('#budgetRows'); if (!rows) return;
    const state = store.get('budget', { values: {}, people: trip.meta.people });
    const brl = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
    const num = v => {
      let s = String(v == null ? '' : v).replace(/[^\d.,-]/g, '');
      if (s.includes(',')) s = s.replace(/\./g, '').replace(',', '.');
      const n = parseFloat(s); return isFinite(n) ? n : 0;
    };
    rows.innerHTML = trip.budget.map(c => `<div class="brow"><label for="b-${c.id}">${esc(c.label)}</label>
      <span class="money"><i>R$</i><input id="b-${c.id}" data-cat="${c.id}" inputmode="decimal" placeholder="0,00" autocomplete="off" value="${esc(state.values[c.id] || '')}"></span></div>`).join('');
    const people = $('#people'); people.value = state.people || trip.meta.people;
    const update = () => {
      const total = trip.budget.reduce((a, c) => a + num(state.values[c.id]), 0);
      const p = Math.max(1, parseInt(people.value, 10) || 1);
      $('#sumTotal').textContent = brl.format(total);
      $('#sumDay').textContent = brl.format(total / totalDays);
      $('#sumPerson').textContent = brl.format(total / p);
      state.people = p; store.set('budget', state);
    };
    rows.addEventListener('input', e => { const c = e.target.dataset.cat; if (!c) return; state.values[c] = e.target.value; update(); });
    people.addEventListener('input', update);
    update();
  }

  /* ---------------------------------------- campos salvos (sky bar, pôr do sol, dia 4) */
  function initFields() {
    $$('[data-store]').forEach(el => {
      const key = el.dataset.store, f = el.dataset.field;
      const saved = store.get(key, {});
      if (saved[f] != null) el.value = saved[f];
      el.addEventListener('input', () => {
        const cur = store.get(key, {}); cur[f] = el.value; store.set(key, cur);
        if (key === 'skybar' && f === 'endereco') syncSkybarLink();
      });
    });
    syncSkybarLink();
    const btn = $('#day4Btn'), panel = $('#day4Panel');
    if (btn) btn.addEventListener('click', () => {
      panel.hidden = !panel.hidden; btn.setAttribute('aria-expanded', String(!panel.hidden));
      btn.textContent = panel.hidden ? 'CONTINUAR PLANEJANDO' : 'FECHAR';
    });
  }
  function syncSkybarLink() {
    const a = $('#skybarMap'); if (!a) return;
    const addr = (store.get('skybar', {}).endereco || '').trim();
    a.href = addr ? 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(addr) : mapsLink('Sky bar');
  }

  /* -------------------------------------------------------------------- init */
  buildDeck();
  initNav();
  initPlaces();
  initCountdown();
  initRace();
  initMap();
  initLightbox();
  initChecklist();
  initBudget();
  initFields();
})();
