/* ==========================================================================
   JOÃO PESSOA · ROAD TO 3ª MEIA — dados do roteiro
   Tudo o que aparece no site vem daqui. Edite textos, fotos, locais,
   checklist e categorias de orçamento sem mexer no layout.

   FOTOS: use um caminho relativo a meta.imageBase (ex.: "day01/opener.jpg")
   ou uma URL completa (https://...). Se a foto não existir, o site mostra
   um fundo em degradê no lugar — nada quebra.
   ========================================================================== */

const raceStartInfo = {
  time: "04:30",
  place: "Em frente à Empadinha Barnabé",
  address: "Av. Cabo Branco, nº 1758, Cabo Branco, João Pessoa/PB",
  mapQuery: "Empadinha Barnabé Av. Cabo Branco 1758 Cabo Branco"
};

const trip = {
  meta: {
    name: "João Pessoa",
    tagline: "Road to 3ª meia",
    subtitle: "Uma viagem em quatro dias. Uma meia maratona no meio dela.",
    range: "13 — 16 NOV",
    place: "João Pessoa, Paraíba",
    imageBase: "assets/images/",
    heroImage: "general/tambau.jpg",
    lodging: { name: "Eco Summer - Conforto & Lazer", address: "Avenida Antônio Lira, 95 — Praia de Tambaú" },
    people: 4,                                   // padrão do "gasto por pessoa"
    raceStart: "2026-11-15T04:30:00-03:00",      // largada (contador)
    raceEnd: "2026-11-16T00:00:00-03:00"         // depois disso: "Prova concluída"
  },

  intro: {
    lines: ["4 dias.", "1 meia maratona.", "Muitas histórias."],
    text: "Uma viagem pensada para correr, conhecer João Pessoa, comer bem e aproveitar cada momento."
  },

  /* ---------- DIAS ----------
     Cada dia tem "scenes" (as telas do dia) e "activities" (resumo usado na
     timeline final). Tipos de cena: opener, steps, feature, statement,
     places, race, racekm, sunset, skybar, loading.                       */
  days: [
    {
      day: 1, title: "Chegada", date: "13/11/2026", short: "13 NOV",
      activities: ["Chegada", "Café da manhã", "Expo da meia", "Almoço na Forneria de Origem", "Check-in 15:00", "Trattoria de Origem", "Orla Tambaú/Cabo Branco"],
      scenes: [
        { id: "d1-open", type: "opener", tone: "sea", image: "general/tambau.jpg",
          subtitle: "Primeiro contato com João Pessoa." },

        { id: "d1-manha", type: "steps", tone: "dawn", image: "day01/manha.jpg",
          kicker: "Manhã", title: "Da estrada à primeira parada",
          steps: [
            { title: "Chegada", text: "Chegamos pela manhã." },
            { title: "Café da manhã", text: "Primeira parada antes de começar o roteiro." }
          ] },

        { id: "d1-expo", type: "feature", tone: "race", image: "general/half.jpg",
          kicker: "Retirada do kit", title: "Expo da meia", figure: { src: "general/medalha.jpg", caption: "Camiseta e medalha da meia" },
          tags: ["Kit", "Corrida", "Produtos", "Clima de prova"],
          text: "Retirar o kit da prova — e passar bastante tempo na Expo, olhando os produtos, o ambiente e as atrações.",
          address: "Espaço Cultural José Lins do Rêgo · R. Abdias Gomes de Almeida, 800 — Tambauzinho, João Pessoa/PB, 58042-900",
          mapQuery: "Espaço Cultural José Lins do Rêgo R. Abdias Gomes de Almeida 800 Tambauzinho" },

        { id: "d1-almoco", type: "feature", tone: "dawn", image: "",
          kicker: "Almoço · sexta, 13/11", title: "Forneria de Origem",
          text: "Depois da Expo, hora de almoçar.",
          figure: { src: "day01/forneria.jpg", caption: "Forneria de Origem" },
          mapQuery: "Forneria de Origem", timeField: "forneria" },

        { id: "d1-tarde", type: "steps", tone: "sea", image: "day01/tarde.jpg",
          kicker: "Depois do almoço", title: "Tempo livre",
          steps: [
            { title: "Tempo livre", text: "Algum lugar para passar o tempo até o horário do check-in.",
              ideas: [] }   // ex.: ["Feirinha de artesanato", "Picolé na orla"]
          ] },

        { id: "d1-checkin", type: "feature", tone: "dawn", image: "day01/checkin.jpg",
          big: "15:00", kicker: "Check-in", title: "Eco Summer",
          text: "Hora de finalmente deixar as malas, tomar banho e começar a preparação para a noite.",
          address: "Eco Summer - Conforto & Lazer · Avenida Antônio Lira, 95 — Praia de Tambaú",
          mapQuery: "Eco Summer Conforto & Lazer Avenida Antônio Lira 95 Tambaú" },

        { id: "d1-massa", type: "feature", tone: "night", image: "",
          kicker: "Massa italiana · jantar", title: "Trattoria de Origem",
          text: "Carboidrato, descanso e preparação.",
          figure: { src: "day01/trattoria.jpg", caption: "Trattoria de Origem" },
          mapQuery: "Trattoria de Origem", timeField: "trattoria" },

        { id: "d1-orla", type: "feature", tone: "night", image: "general/cabo-branco.jpg", imagePos: "50% 42%",
          kicker: "Orla", title: "Cabo Branco → Tambaú",
          text: "Depois do jantar, uma caminhada leve pela orla." }
      ]
    },
    {
      day: 2, title: "João Pessoa Histórica", date: "14/11/2026", short: "14 NOV",
      activities: ["Corrida na orla", "Café na Casa Mielo", "Centro Histórico", "Almoço no Tortlas", "Mercado", "Jantar em casa"],
      scenes: [
        { id: "d2-open", type: "opener", tone: "hist", image: "day02/centro-historico.jpg",
          subtitle: "Antes da prova, conhecer a cidade." },

        { id: "d2-manha", type: "steps", tone: "dawn", image: "day02/manha.jpg",
          kicker: "Manhã", title: "Corrida na orla",
          steps: [
            { title: "Corrida na orla", text: "Correremos cedo pela orla." },
            { title: "Café da manhã", text: "Casa Mielo.", tag: "a confirmar", mapQuery: "Casa Mielo", timeField: "mielo" },
            { title: "Preparação", text: "Tomar banho, se arrumar e sair para conhecer a cidade." }
          ] },

        { id: "d2-centro", type: "places", tone: "hist", image: "day02/centro-historico.jpg",
          kicker: "Centro Histórico", title: "Três paradas",
          placeIds: ["ccsf", "hotel-globo", "centro-historico"] },

        { id: "d2-almoco", type: "feature", tone: "dawn", image: "",
          kicker: "Almoço", title: "Tortlas",
          text: "Pausa para almoçar depois de caminhar pelo Centro Histórico.",
          figure: { src: "day02/tortlas.jpg", caption: "Tortlas" },
          mapQuery: "Tortlas", timeField: "tortlas" },

        { id: "d2-fim", type: "statement", tone: "night", image: "day02/noite.jpg",
          lines: ["Volta para o hotel", "Passar no mercado", "Jantar em casa", "Dormir."],
          note: "Amanhã é dia de prova." }
      ]
    },
    {
      day: 3, title: "Race Day", date: "15/11/2026", short: "15 NOV",
      activities: ["Largada 04:30", "21,1 km", "Medalha", "Praia do Bessa", "Pôr do sol no Cibelly Mar", "Sky bar"],
      scenes: [
        { id: "d3-open", type: "race", tone: "race", image: "general/half.jpg", start: raceStartInfo },

        { id: "d3-prova", type: "racekm", tone: "race", image: "general/half.jpg", start: raceStartInfo,
          kicker: "A manhã da prova", title: "Da largada à medalha",
          steps: [
            { title: "Acordar" },
            { title: "Preparação" },
            { title: "Largada", time: "04:30" },
            { title: "21,1 km" },
            { title: "Chegada" },
            { title: "Medalha" }
          ],
          marks: [0, 5, 10, 15, 21.1] },

        { id: "d3-pos", type: "steps", tone: "sea", image: "day03/bessa.jpg", imagePos: "50% 62%",
          kicker: "Pós-prova", title: "Recuperar e praia",
          steps: [
            { title: "Recuperar" },
            { title: "Praia do Bessa", text: "No domingo da prova, depois de recuperar.", mapQuery: "Praia do Bessa" }
          ] },

        { id: "d3-sunset", type: "sunset", tone: "sunset", image: "general/praia-do-jacare.jpg",
          title: "Pôr do sol do Jacaré",
          text: "Depois da prova, seguimos para assistir ao pôr do sol com o Cibelly Mar.",
          mapQuery: "Cibelly Mar Jacaré" },

        { id: "d3-skybar", type: "skybar", tone: "night", image: "general/sky-bar.jpg",
          title: "Sky bar", text: "Para fechar o dia da prova." },

        { id: "d3-fim", type: "statement", tone: "race", image: "day03/fim.jpg",
          lines: ["21,1 km concluídos.", "Dia vivido.", "Noite ainda não terminou."] }
      ]
    },
    {
      day: 4, title: "Ponta de Campina", date: "16/11/2026", short: "16 NOV",
      activities: ["Ponta de Campina", "Happy hour 15:00 no Bar do Cuscuz"],
      scenes: [
        { id: "d4-open", type: "opener", tone: "sea", image: "day04/ponta-de-campina.jpg",
          subtitle: "O último capítulo: mar e um happy hour para fechar." },

        { id: "d4-ponta", type: "feature", tone: "sea", image: "day04/ponta-de-campina.jpg",
          kicker: "Último dia · segunda, 16/11", title: "Ponta de Campina",
          text: "A manhã do último dia é de mar, sem pressa.",
          mapQuery: "Ponta de Campina Cabedelo" },

        { id: "d4-happy", type: "feature", tone: "night", image: "",
          big: "15:00", kicker: "Happy hour · segunda, 16/11", title: "Bar do Cuscuz",
          text: "Para fechar a viagem.",
          figure: { src: "day04/bar-do-cuscuz.jpg", caption: "Bar do Cuscuz · desde 1973" },
          mapQuery: "Bar do Cuscuz" },

        { id: "d4-fim", type: "statement", tone: "night", image: "general/tambau.jpg",
          lines: ["4 dias.", "1 meia maratona.", "Muitas histórias."] }
      ]
    }
  ],

  /* ---------- PONTOS TURÍSTICOS (Dia 02) ----------
     Sem horários ou preços de propósito. "query" alimenta o botão "Ver no mapa". */
  places: [
    { id: "ccsf", name: "Centro Cultural e Igreja de São Francisco", image: "day02/ccsf.jpg",
      desc: "Conjunto barroco que reúne igreja, convento e claustros, com a fachada que é cartão-postal da cidade.",
      query: "Centro Cultural São Francisco" },
    { id: "hotel-globo", name: "Hotel Globo", image: "day02/hotel-globo.jpg",
      desc: "Casarão do Varadouro, com vista para o Rio Sanhauá.",
      query: "Hotel Globo" },
    { id: "antenor-navarro", name: "Praça Antenor Navarro", image: "day02/antenor-navarro.jpg",
      desc: "Praça do Varadouro, cercada de casarões históricos.",
      query: "Praça Antenor Navarro" },
    { id: "centro-historico", name: "Centro Histórico de João Pessoa", image: "day02/centro-historico.jpg",
      desc: "Igrejas, praças e casarões que contam a origem da cidade.",
      query: "Centro Histórico" }
  ],

  /* ---------- SKY BAR: campos editáveis (salvos no navegador) ---------- */
  skybar: { fields: ["Horário", "Endereço", "Reserva", "Observações"] },

  /* ---------- MAPA ----------
     Coordenadas APROXIMADAS (ajuste quando tiver os endereços exatos).
     lat/lng = null -> aparece na lista como "definir local".                */
  locations: [
    { id: "forneria", name: "Forneria de Origem", day: 1, lat: null, lng: null, note: "Almoço de sexta" },
    { id: "expo",     name: "Expo — Espaço Cultural José Lins do Rêgo", day: 1, lat: null, lng: null,
      note: "R. Abdias Gomes de Almeida, 800 · Tambauzinho",
      query: "Espaço Cultural José Lins do Rêgo R. Abdias Gomes de Almeida 800 Tambauzinho" },
    { id: "largada", name: "Largada — Empadinha Barnabé", day: 3, lat: null, lng: null,
      note: "Av. Cabo Branco, 1758 · 04:30",
      query: "Empadinha Barnabé Av. Cabo Branco 1758 Cabo Branco" },
    { id: "hotel",    name: "Eco Summer (hospedagem)", day: 1, lat: -7.1158, lng: -34.8230,
      note: "Av. Antônio Lira, 95 · posição aproximada" },
    { id: "trattoria", name: "Trattoria de Origem", day: 1, lat: null, lng: null, note: "Jantar de massas" },
    { id: "tambau",   name: "Tambaú", day: 1, lat: -7.1153, lng: -34.8236, note: "Orla" },
    { id: "cabobranco", name: "Cabo Branco", day: 1, lat: -7.1390, lng: -34.8170, note: "Orla" },
    { id: "mielo",    name: "Casa Mielo (a confirmar)", day: 2, lat: null, lng: null, note: "Café da manhã" },
    { id: "centro",   name: "Centro Histórico", day: 2, lat: -7.1195, lng: -34.8830, note: "São Francisco, Hotel Globo" },
    { id: "tortlas",  name: "Tortlas", day: 2, lat: null, lng: null, note: "Almoço" },
    { id: "praia",    name: "Praia do Bessa", day: 3, lat: -7.0750, lng: -34.8315,
      note: "Domingo, depois da prova · posição aproximada" },
    { id: "jacare",   name: "Cibelly Mar · pôr do sol do Jacaré", day: 3, lat: -6.9660, lng: -34.8410, note: "Posição aproximada do Jacaré" },
    { id: "ponta",    name: "Ponta de Campina", day: 4, lat: null, lng: null, note: "Último dia" },
    { id: "cuscuz",   name: "Bar do Cuscuz", day: 4, lat: null, lng: null, note: "Happy hour · 15:00" },
    { id: "skybar",   name: "Sky bar", day: 3, lat: null, lng: null, note: "Defina o endereço" }
  ],

  /* ---------- GALERIA ----------  size: xl | tall | wide | sm */
  gallery: [
    { src: "general/tambau.jpg", caption: "Orla de Tambaú", size: "xl", tone: "sea" },
    { src: "general/cabo-branco.jpg", caption: "Orla do Cabo Branco", size: "tall", tone: "dawn" },
    { src: "day02/centro-historico.jpg", caption: "Centro Histórico", size: "wide", tone: "hist" },
    { src: "day02/hotel-globo.jpg", caption: "Hotel Globo", size: "wide", tone: "hist" },
    { src: "general/medalha.jpg", caption: "Camiseta e medalha da meia", size: "tall", tone: "race" },
    { src: "general/joao-pessoa.jpg", caption: "Mar de João Pessoa", size: "xl", tone: "sea" },
    { src: "general/praia-do-jacare.jpg", caption: "Pôr do sol do Jacaré", size: "wide", tone: "sunset" },
    { src: "general/sky-bar.jpg", caption: "Sky bar", size: "wide", tone: "night" },
    { src: "general/half.jpg", caption: "Largada da meia", size: "sm", tone: "race" },
    { src: "day01/trattoria.jpg", caption: "Trattoria de Origem", size: "sm", tone: "night" },
    { src: "day04/ponta-de-campina.jpg", caption: "Ponta de Campina", size: "sm", tone: "sea" }
  ],


  /* ---------- CHECKLIST ---------- */
  checklist: [
    { group: "Reservas", items: [
      "Almoço 13/11 — Forneria de Origem",
      "Hospedagem — Eco Summer (Tambaú)",
      "Jantar 13/11 — Trattoria de Origem",
      "Café 14/11 — Casa Mielo (a confirmar)",
      "Almoço 14/11 — Tortlas",
      "Pôr do sol 15/11 — Cibelly Mar",
      "Sky bar — 15/11 (noite)",
      "Happy hour 16/11, 15:00 — Bar do Cuscuz"
    ] },
    { group: "Antes de sair", items: ["Passagens", "Documento", "Dinheiro/cartão", "Carregadores"] },
    { group: "Corrida", items: ["Kit da prova", "Tênis", "Roupas de corrida", "Fones"] },
    { group: "Praia e sol", items: ["Protetor solar", "Óculos de sol", "Roupa de banho e toalha"] },
    { group: "Lembretes", items: ["Passar no mercado — jantar em casa (14/11)"] }
  ],


  /* ---------- ORÇAMENTO ---------- */
  budget: [
    { id: "transporte", label: "Transporte" },
    { id: "hospedagem", label: "Hospedagem" },
    { id: "alimentacao", label: "Alimentação" },
    { id: "corrida", label: "Corrida" },
    { id: "passeios", label: "Passeios" },
    { id: "praia", label: "Praia" },
    { id: "bebidas", label: "Bebidas" },
    { id: "extras", label: "Extras" }
  ]
};
